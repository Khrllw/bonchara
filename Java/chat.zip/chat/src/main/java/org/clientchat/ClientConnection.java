package org.clientchat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * Класс для установления защищенного соединения с сервером (через SSL) и отправки/приема сообщений.
 */
public class ClientConnection {
    private static final Logger logger = LogManager.getLogger(ClientConnection.class);
    private final String host;
    private final int port;
    private SSLSocket sslSocket;
    private BufferedReader reader;
    private PrintWriter writer;

    /**
     * Конструктор для подключения к серверу по указанному адресу и порту через SSL.
     * @param host Адрес сервера.
     * @param port Порт сервера.
     */
    public ClientConnection(String host, int port) {
        this.host = host;
        this.port = port;
        try {
            connect();
        } catch (IOException e) {
            logger.error("Ошибка при подключении к серверу: ", e);
        }
    }

    /**
     * Устанавливает защищенное соединение с сервером.
     * @throws IOException В случае ошибки при подключении.
     */
    private void connect() throws IOException, NullPointerException {
        try {
            // Получаем путь к файлу serverkeystore.jks из ресурсов
            String trustStorePath = Objects.requireNonNull(getClass().getClassLoader().getResource("serverkeystore.jks")).getPath();

            // Устанавливаем свойства для хранилища доверенных сертификатов
            System.setProperty("javax.net.ssl.trustStore", trustStorePath);
            System.setProperty("javax.net.ssl.trustStorePassword", "xezzexserverkey");

            // Создаем SSL-сокет
            SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            sslSocket = (SSLSocket) factory.createSocket(host, port);

            // Создаем потоки ввода и вывода для общения через защищенное соединение
            reader = new BufferedReader(new InputStreamReader(sslSocket.getInputStream(), StandardCharsets.UTF_8));
            writer = new PrintWriter(new OutputStreamWriter(sslSocket.getOutputStream(), StandardCharsets.UTF_8), true);

            logger.info("Установлено защищенное соединение с сервером {}:{}", host, port);
        } catch (javax.net.ssl.SSLException e) {
            // Игнорируем ошибки SSL и продолжаем выполнение
            logger.error("Ошибка SSL при установлении соединения: ", e);
        } catch (IOException | NullPointerException e) {
            // Игнорируем ошибки I/O и продолжаем выполнение
            logger.error("Ошибка при установлении соединения: ", e);
        }
    }

    /**
     * Отправляет сообщение на сервер.
     * @param message Сообщение для отправки.
     * @throws IOException В случае ошибки при отправке.
     */
    public void sendMessage(String message) throws IOException {
        if (message == null || message.trim().isEmpty()) {
            throw new IllegalArgumentException("Сообщение не может быть пустым.");
        }
        writer.println(message);
    }

    /**
     * Принимает сообщение от сервера.
     * @return Сообщение от сервера.
     * @throws IOException В случае ошибки при получении.
     */
    public String receiveMessage() throws IOException {
        try {
            return reader.readLine();
        } catch (IOException e) {
                logger.warn("Соединение закрыто.");
            }
        return null;
    }

    /**
     * Проверяет, подключен ли клиент к серверу.
     * @return true, если подключение активно.
     */
    public boolean isConnected() throws NullPointerException {
        return sslSocket != null && sslSocket.isConnected();
    }

    /**
     * Закрывает соединение с сервером.
     */
    public void close() {
        try {
            if (sslSocket != null) {
                sslSocket.close();
            }

            if (reader != null) {
                reader.close();
            }

        } catch (IOException e) {
            logger.error("Ошибка при закрытии соединения: ", e);
        }
    }
}