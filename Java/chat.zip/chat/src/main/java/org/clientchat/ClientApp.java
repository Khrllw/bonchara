package org.clientchat;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.*;

/**
 * Главный класс приложения клиента чата.
 * Реализует интерфейс пользователя и логику подключения к серверу.
 */
public class ClientApp extends Application {

    private ScheduledExecutorService userListSheduler;
    private ClientConnection connection;
    private MessageHandler messageHandler;
    private Stage primaryStage;
    private final UIHandler uiHandler = new UIHandler();
    private Label userCountLabel;
    private TextArea messagesArea;
    private final ListView<String> userList = new ListView<>();
    private boolean isAdminWindowOpen = false;
    private volatile boolean isWindowClosed = false;
    private volatile boolean isApplicationRunning = true;


    /**
     * Метод для запуска приложения, точка входа в программу.
     */
    public static void applaunch() {
        launch();
    }

    /**
     * Инициализация главного окна и отображение окна входа.
     *
     * @param primaryStage Главная сцена приложения.
     */
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;

        // Обработчик закрытия окна
        primaryStage.setOnCloseRequest(_ -> {
            isWindowClosed = true; // Устанавливаем флаг при закрытии окна
            handleExit(); // Завершаем соединение
        });

        showLoginWindow();
    }

    /**
     * Отображает окно входа, где пользователь вводит имя и параметры подключения.
     */
    private void showLoginWindow() {
        Label namePrompt = uiHandler.createNamePrompt();
        TextField nameField = uiHandler.createNameField();
        TextField ipField = uiHandler.createIPField();
        TextField portField = uiHandler.createPortField();

        Button enterButton = uiHandler.createEnterButton(nameField, namePrompt, null, () -> {
            try {
                handleLogin(nameField, ipField, portField);
            } catch (Exception e) {
                showErrorAlert("Ошибка входа", e.getMessage());
            }
        });

        // Добавляем GIF в правый нижний угол
        ImageView gifImageView = createGifImageView("/img/loading.gif");

        VBox loginLayout = new VBox(10, namePrompt, nameField, ipField, portField, enterButton);
        loginLayout.setPadding(new javafx.geometry.Insets(20));

        // Используем StackPane, чтобы добавить GIF в правый нижний угол
        StackPane rootLayout = new StackPane();
        rootLayout.getChildren().addAll(loginLayout, gifImageView);
        StackPane.setAlignment(gifImageView, javafx.geometry.Pos.BOTTOM_RIGHT);

        Scene loginScene = new Scene(rootLayout, 300, 250);
        loginScene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/img/styles.css")).toExternalForm());

        primaryStage.getIcons().add(uiHandler.loadAppIcon().getImage());
        primaryStage.setTitle("Chat Login");
        primaryStage.setScene(loginScene);
        primaryStage.show();
    }

    /**
     * Обрабатывает процесс входа пользователя, проверяя корректность введенных данных.
     * Выполняет подключение к серверу с использованием введенных имени, IP и порта.
     * Использование функционала StreamAPI.
     *
     * @param nameField Поле ввода имени пользователя.
     * @param ipField   Поле ввода IP-адреса сервера.
     * @param portField Поле ввода порта сервера.
     * @throws IllegalArgumentException Если имя пользователя пустое или порт не является числом.
     */
    private void handleLogin(TextField nameField, TextField ipField, TextField portField) {
        String name = nameField.getText().trim();
        List<String> invalidNames = Arrays.asList("admin", "root", "админ", "администратор");
        boolean isValid = invalidNames.stream().noneMatch(name::equalsIgnoreCase);

        if (name.isEmpty()) {
            throw new IllegalArgumentException("Имя пользователя обязательно для входа.");
        } else if (!isValid) {
            throw new IllegalArgumentException("Имя пользователя недопустимо.");
        }

        String ip = ipField.getText().trim();
        int port;
        try {
            port = Integer.parseInt(portField.getText().trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Порт должен быть числом.");
        }

        connectToServer(name, ip, port);
    }

    /**
     * Подключает клиента к серверу с указанным именем, IP и портом.
     *
     * @param name Имя пользователя.
     * @param ip   Адрес сервера.
     * @param port Порт сервера.
     */
    private void connectToServer(String name, String ip, int port) {
        try {
            connection = new ClientConnection(ip, port);

            if (!connection.isConnected()) {
                throw new IOException("Не удалось подключиться к серверу.");
            }

            messageHandler = new MessageHandler(connection);
            messageHandler.sendMessage(name); // Отправляем имя пользователя

            // Обычный пользователь
            showChatWindow("суперадмин".equalsIgnoreCase(name)); // Открываем окно чата с кнопкой администратора
            listenForMessages();
        } catch (Exception e) {
            showErrorAlert("Ошибка подключения", e.getMessage());
        }
    }

    /**
     * Отображает основное окно чата.
     *
     * @param isAdmin Флаг, указывающий, является ли пользователь суперадмином.
     */

    private void showChatWindow(boolean isAdmin) {
        messagesArea = uiHandler.createMessagesArea();
        TextField messageField = uiHandler.createMessageField();
        Button sendButton = uiHandler.createSendButton();

        userCountLabel = new Label("Количество пользователей на сервере: 0");

        sendButton.setOnAction(_ -> {
            try {
                handleSendMessage(messageField);
            } catch (Exception ex) {
                appendMessageToChat(messagesArea, "Ошибка отправки сообщения: " + ex.getMessage());
            }
        });

        Button adminButton = isAdmin ? uiHandler.createAdminButton() : null;

        VBox chatLayout = uiHandler.createChatLayout(userCountLabel, messagesArea, messageField, sendButton, adminButton);

        if (adminButton != null) {
            adminButton.setOnAction(_ -> showAdminWindow());
        }

        primaryStage.setOnCloseRequest(_ -> handleExit());

        // Добавляем GIF в правый нижний угол
        ImageView gifImageView = createGifImageView("/img/loading.gif");

        // Используем StackPane для контейнера
        StackPane rootLayout = new StackPane();
        rootLayout.getChildren().addAll(chatLayout, gifImageView);
        StackPane.setAlignment(gifImageView, javafx.geometry.Pos.BOTTOM_RIGHT);

        Scene chatScene = new Scene(rootLayout, 550, 400);
        chatScene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/img/styles.css")).toExternalForm());
        primaryStage.getIcons().add(uiHandler.loadAppIcon().getImage());
        primaryStage.setScene(chatScene);
    }

    /**
     * Создает и возвращает объект ImageView, отображающий GIF-изображение.
     *
     * @param gifPath Путь к файлу GIF-изображения, который будет загружен.
     * @return Возвращает ImageView с загруженным изображением.
     */
    private ImageView createGifImageView(String gifPath) {
        Image gifImage = new Image(Objects.requireNonNull(getClass().getResource(gifPath)).toExternalForm());
        ImageView gifImageView = new ImageView(gifImage);
        gifImageView.setFitHeight(69); // Установите нужный размер
        gifImageView.setFitWidth(69);
        return gifImageView;
    }

    /**
     * Отображает окно управления для суперадмина в виде нового окна.
     */
    private void showAdminWindow() {
        Stage adminStage = new Stage();
        Button disconnectButton = new Button("Отключить");
        Button closeAdminButton = new Button("Закрыть");

        // Устанавливаем флаг, указывающий на открытие окна администратора
        isAdminWindowOpen = true;

        disconnectButton.setOnAction(_ -> {
            String selectedUser = userList.getSelectionModel().getSelectedItem();
            if (selectedUser != null) {
                messageHandler.sendMessage("/kick " + selectedUser); // Команда отключения
            } else {
                appendMessageToChat(messagesArea, "Пожалуйста, выберите пользователя.");
            }
        });

        closeAdminButton.setOnAction(_ -> {
            isAdminWindowOpen = false; // Устанавливаем флаг, указывающий, что окно закрыто
            adminStage.close();
            stopAdminWindowProcesses(); // Останавливаем процессы, связанные с админским окном
        });

        // Проверяем, если окно администратора открыто, запускаем планировщик
        if (isAdminWindowOpen) {
            userListSheduler = Executors.newSingleThreadScheduledExecutor();
            userListSheduler.scheduleAtFixedRate(this::updateUserList, 0, 3, TimeUnit.SECONDS);
        }

        // Размещение кнопок горизонтально с помощью HBox
        HBox buttonLayout = new HBox(10, disconnectButton, closeAdminButton);
        buttonLayout.setPadding(new javafx.geometry.Insets(10));

        // Создание VBox для основного содержимого окна администратора
        VBox adminLayout = new VBox(10, new Label("Список пользователей:"), userList, buttonLayout);
        adminLayout.setPadding(new javafx.geometry.Insets(20));

        // Стилизация через CSS
        Scene adminScene = new Scene(adminLayout, 400, 400);
        adminScene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/img/styles.css")).toExternalForm());

        adminStage.setScene(adminScene);
        adminStage.setTitle("Окно администратора");

        // Закрытие окна администратора при закрытии главного окна
        adminStage.setOnCloseRequest(_ -> {
            isAdminWindowOpen = false;
            stopAdminWindowProcesses(); // Останавливаем процессы, связанные с админским окном
        });

        adminStage.setOnCloseRequest(_ -> isAdminWindowOpen = false); // Устанавливаем флаг при закрытии окна
        adminStage.show();
    }

    private void stopAdminWindowProcesses() {
        if (userListSheduler != null) {
            userListSheduler.shutdownNow(); // Останавливаем обновление списка пользователей
        }
        System.out.println("Процессы окна администратора успешно завершены.");
    }


    /**
     * Обновляет список пользователей в окне администратора.
     */
    private void updateUserList() {
        if (!isAdminWindowOpen || !isApplicationRunning || connection == null || !connection.isConnected()) {
            return; // Не обновляем список, если приложение завершено
        }


        String selectedUser = userList.getSelectionModel().getSelectedItem();

        Thread userListUpdater = new Thread(() -> {
            try {
                String message;
                messageHandler.sendMessage("/list");
                while ((message = messageHandler.receiveMessage()) != null) {
                    if (message.startsWith("/users ")) {
                        String userData = message.substring(7);
                        List<String> users = Arrays.asList(userData.split(","));
                        Platform.runLater(() -> {
                            userList.getItems().clear();
                            userList.getItems().addAll(users);

                            if (selectedUser != null && users.contains(selectedUser)) {
                                userList.getSelectionModel().select(selectedUser);
                            }
                        });
                    } else {
                        handleIncomingMessage(message);
                    }
                }
            } catch (Exception e) {
                if (isApplicationRunning) {
                    Platform.runLater(() -> {
                        showErrorAlert("Ошибка", "Ошибка обновления списка пользователей.");
                        handleExit();
                    });
                }
            }
//            } catch (Exception e) {
//                if (isAdminWindowOpen && isApplicationRunning) {
//                    Platform.runLater(() -> {
//                        showErrorAlert("Ошибка", "Ошибка обновления списка пользователей.");
//                    });
//                }
//            }
        });
        userListUpdater.setDaemon(true);
        userListUpdater.start();
    }


    /**
     * Обрабатывает отправку сообщения. Проверяет, что сообщение не пустое и что клиент подключен к серверу.
     * Если все проверки пройдены, отправляет сообщение и добавляет его в чат.
     * Если подключение отсутствует, выводит соответствующее сообщение в чат.
     *
     * @param messageField Поле ввода сообщения.
     * @throws IllegalArgumentException Если сообщение пустое.
     */
    private void handleSendMessage(TextField messageField) {
        String message = messageField.getText();
        if (message.isEmpty()) {
            throw new IllegalArgumentException("Сообщение не может быть пустым.");
        }
        if (connection != null && connection.isConnected()) {
            messageHandler.sendMessage(message);
            appendMessageToChat(messagesArea, "Вы: " + message);
            messageField.clear();
        } else {
            appendMessageToChat(messagesArea, "Вы не подключены к серверу.");
        }
    }

    /**
     * Закрывает соединение с сервером и завершает работу приложения.
     */
    private void handleExit() {
        try {
            isApplicationRunning = false;
            isWindowClosed = true;

            // Останавливаем планировщик, если он существует
            if (userListSheduler != null) {
                userListSheduler.shutdownNow(); // Останавливаем планировщик
            }

            // Закрываем соединение с сервером
            if (messageHandler != null) {
                messageHandler.closeConnection(); // Закрытие соединения
            }

            if (connection != null && connection.isConnected()) {
                connection.close(); // Закрываем сокет
            }

            System.out.println("Соединение корректно закрыто.");
        } catch (Exception e) {
            System.err.println("Ошибка при закрытии соединения: " + e.getMessage());
        }
        // Корректное завершение JavaFX-приложения
        Platform.exit();
        System.exit(0);

    }

    /**
     * Добавляет новое сообщение в область чата.
     *
     * @param messagesArea Область сообщений.
     * @param message      Сообщение для добавления.
     */
    private void appendMessageToChat(TextArea messagesArea, String message) {
        messagesArea.appendText(message + "\n");
    }

    /**
     * Запускает поток для прослушивания сообщений от сервера.
     */
    private void listenForMessages() {
        Thread messageListener = new Thread(() -> {
            try {
                String message;
                while (!(isWindowClosed)) {
                    assert messageHandler != null;
                    message = messageHandler.receiveMessage();
                    if (message != null) {
                        if (message.startsWith("/role ")) {
                            String role = message.split(" ")[1].trim();
                            Platform.runLater(() -> showChatWindow("суперадмин".equalsIgnoreCase(role)));
                        } else if (message.startsWith("/error ")) {
                            String errorMessage = message.substring(7);
                            if ("Разрыв соединения".equals(errorMessage)) {
                                Platform.runLater(() -> showErrorAlert("Ошибка", errorMessage));
                                break; // Прерываем цикл
                            } else if (errorMessage.startsWith("Имя пользователя")) {
                                Platform.runLater(() -> showErrorAlert("Ошибка имени", errorMessage));
                                break; // Прерываем цикл
                            } else {
                                Platform.runLater(() -> appendMessageToChat(messagesArea, "Ошибка: " + errorMessage));
                            }
                        } else if (message.startsWith("/banned ")) {
                            String reason = message.substring(8);
                            Platform.runLater(() -> {
                                showErrorAlert("Вы забанены", reason);
                                messageHandler.closeConnection(); // Закрываем соединение
                            });
                            break; // Прерываем цикл после закрытия
                        } else {
                            handleIncomingMessage(message);
                        }
                    }
                }
            } catch (Exception e) {
                if (!isWindowClosed && isApplicationRunning) {
                    Platform.runLater(() -> {
                        showErrorAlert("Разрыв соединения", "Соединение с сервером потеряно.");
                        handleExit();
                    });
                } else if (!"Socket closed".equals(e.getMessage())) {
                    Platform.runLater(() -> appendMessageToChat(messagesArea, "Ошибка при получении сообщения: " + e.getMessage()));
                }
            }
        });
        messageListener.setDaemon(true);
        messageListener.start();
    }


    /**
     * Обрабатывает входящее сообщение от сервера. Если сообщение содержит информацию о количестве пользователей на сервере,
     * обновляется метка с количеством пользователей. В противном случае сообщение добавляется в чат.
     *
     * @param message Сообщение, полученное от сервера.
     */
    private void handleIncomingMessage(String message) {
        // Фильтруем сообщения, чтобы исключить команды /role и /users
        if (message.startsWith("/role ") || message.startsWith("/users ")) {
            return; // Игнорируем эти команды
        }

        if (message.startsWith("Количество пользователей на сервере: ")) {
            String userCount = message.split(":")[1].trim();
            Platform.runLater(() -> userCountLabel.setText("Количество пользователей на сервере: " + userCount));
        } else {
            Platform.runLater(() -> appendMessageToChat(messagesArea, message));
        }
    }

    /**
     * Отображает окно с ошибкой.
     *
     * @param title   Заголовок окна.
     * @param content Текст ошибки.
     */
    private void showErrorAlert(String title, String content) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(content);

            // Загружаем изображение для иконки ошибки
            ImageView errorIcon = new ImageView(Objects.requireNonNull(getClass().getResource("/img/error_icon.png")).toExternalForm());
            errorIcon.setFitHeight(50); // Устанавливаем размер иконки
            errorIcon.setFitWidth(50);

            alert.setGraphic(errorIcon);
            alert.getDialogPane().getStylesheets().add(Objects.requireNonNull(getClass().getResource("/img/styles.css")).toExternalForm());

            // Устанавливаем иконку для окна
            Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
            Image windowIcon = new Image(Objects.requireNonNull(getClass().getResource("/img/icon2.png")).toExternalForm());
            stage.getIcons().add(windowIcon);

            // Применяем стиль из CSS
            alert.getDialogPane().getStyleClass().add("alert");

            if ("Вы забанены".equals(title) || "Ошибка имени".equals(title) || "Ошибка".equals(title) && "Разрыв соединения".equals(content)) {
                alert.setOnHidden(_ -> handleExit());
            }
            alert.showAndWait();
        });
    }
}