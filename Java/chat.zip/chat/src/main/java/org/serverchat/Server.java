package org.serverchat;

import org.serverchat.exceptions.*;

import javax.net.ssl.*;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

/**
 * Класс Server предназначен для запуска SSL-сервера чата.
 * Он принимает подключения клиентов и обрабатывает их.
 * Сервер работает на порту 8040 и IP-адресе 127.0.0.1.
 */
public class Server {

    private SSLServerSocket serverSocket;
    private static final int PORT = 8040; // Порт сервера
    private static final String IP = "127.0.0.1"; // IP-адрес сервера
    private static boolean isServerRunning = false; // Флаг для проверки состояния сервера

    /**
     * Точка входа в приложение для запуска сервера.
     * @param args Аргументы командной строки.
     */
    public static void main(String[] args) {
        Server server = new Server();
        server.startServer();
    }

    /**
     * Метод для запуска сервера.
     * Настроить SSL, создать сокет и начать принимать подключения от клиентов.
     * Также регистрирует хук для остановки сервера при завершении работы программы.
     */
    public void startServer() {
        try {
            isServerRunning = true;  // Устанавливаем флаг сервера в true
            SSLContext sslContext = setupSSLContext();
            serverSocket = createServerSocket(sslContext);

            System.out.println("Сервер запущен на IP: " + IP + " и порту: " + PORT);

            Runtime.getRuntime().addShutdownHook(new Thread(() -> stopServer()));

            while (isServerRunning) {
                acceptClientConnection();
            }
        } catch (IOException | SSLConfigurationException | KeyStoreException | ClientConnectionException e) {
            handleServerError(e);
        }
    }

    /**
     * Метод для настройки SSL-контекста для сервера.
     * @return SSLContext настроенный для сервера.
     * @throws SSLConfigurationException При ошибке настройки SSL.
     * @throws KeyStoreException При ошибке загрузки ключевого хранилища.
     */
    private SSLContext setupSSLContext() throws SSLConfigurationException, KeyStoreException {
        try {
            SSLContext sslContext = SSLContext.getInstance("TLS");
            KeyStore keyStore = KeyStore.getInstance("JKS");

            try (InputStream keyStoreInput = Server.class.getResourceAsStream("/serverkeystore.jks")) {
                if (keyStoreInput == null) {
                    throw new KeyStoreException("Не удалось найти ключевое хранилище!");
                }
                keyStore.load(keyStoreInput, "xezzexserverkey".toCharArray());
            }

            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(keyStore, "xezzexserverkey".toCharArray());
            sslContext.init(kmf.getKeyManagers(), null, null);

            return sslContext;

        } catch (Exception e) {
            throw new SSLConfigurationException("Ошибка настройки SSL", e);
        }
    }

    /**
     * Создание SSL-сокета для сервера.
     * @param sslContext SSL-контекст.
     * @return SSL-серверный сокет.
     * @throws IOException При ошибке создания сокета.
     */
    private SSLServerSocket createServerSocket(SSLContext sslContext) throws IOException {
        SSLServerSocketFactory socketFactory = sslContext.getServerSocketFactory();
        return (SSLServerSocket) socketFactory.createServerSocket(PORT, 50, InetAddress.getByName(IP));
    }

    /**
     * Ожидает подключения клиента и передает его в обработчик.
     * @throws ClientConnectionException При ошибке подключения клиента.
     */
    private void acceptClientConnection() throws ClientConnectionException {
        if (!isServerRunning) {
            throw new ClientConnectionException("Сервер остановлен, подключение невозможно");
        }

        try {
            // Проверяем, что серверный сокет не закрыт перед ожиданием подключения
            if (serverSocket != null && !serverSocket.isClosed()) {
                SSLSocket clientSocket = (SSLSocket) serverSocket.accept();
                System.out.println("Клиент подключен: " + clientSocket.getInetAddress());
                ClientHandler clientHandler = new ClientHandler(clientSocket);
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            if (isServerRunning) {
                throw new ClientConnectionException("Ошибка при подключении клиента", e);
            }
        }
    }

    /**
     * Останавливает сервер и разрывает все активные соединения с клиентами.
     * Использование функционала StreamAPI.
     */
    public void stopServer() {
        try {
            isServerRunning = false; // Устанавливаем флаг сервера в false, чтобы не принимать новые подключения
            // Создаем копию списка подключенных клиентов для безопасного обхода
            List<ClientHandler> clientsCopy;

            synchronized (ClientHandler.getConnectedClients()) {
                clientsCopy = new ArrayList<>(ClientHandler.getConnectedClients());
            }

            for (ClientHandler client : clientsCopy) {
                if (!client.clientSocket.isClosed()) {
                    client.sendMessage("/error Разрыв соединения");
                    client.cleanupClientResources(false); // Закрываем соединения
                }
            }

            // Закрываем серверный сокет
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
                System.out.println("Сервер остановлен.");
            }
        } catch (IOException e) {
            System.err.println("Ошибка при остановке сервера: " + e.getMessage());
        }
    }

    public static boolean isServerRunning() {
        return isServerRunning;
    }


    /**
     * Обработка ошибок при запуске сервера.
     * @param e Исключение, которое произошло.
     */
    private void handleServerError(Exception e) {
        if (e instanceof java.net.BindException) {
            System.err.println("Ошибка: Порт " + PORT + " уже используется. Попробуйте другой порт.");
        } else {
            System.err.println("Ошибка при запуске сервера: " + e.getMessage());
        }
    }
}