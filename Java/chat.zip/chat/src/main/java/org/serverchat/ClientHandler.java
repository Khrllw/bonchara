package org.serverchat;

import javax.net.ssl.SSLSocket;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Класс, обрабатывающий клиента на сервере.
 * Он управляет подключениями, регистрацией имен пользователей,
 * отправкой сообщений и выполнением команд администратора.
 */
public class ClientHandler implements Runnable {

    public SSLSocket clientSocket;
    private PrintWriter outputWriter;
    private BufferedReader inputReader;
    private String username;
    private volatile boolean isClosed = false;

    private static final String SUPERADMIN_NAME = "суперадмин";
    private static boolean superAdminConnected = false; // Флаг подключения суперадмина
    private static final List<ClientHandler> connectedClients = Collections.synchronizedList(new ArrayList<>());

    /**
     * Конструктор для создания обработчика клиента.
     *
     * @param clientSocket Сокет клиента для обмена данными.
     */
    public ClientHandler(SSLSocket clientSocket) {
        this.clientSocket = clientSocket;
    }

    /**
     * Основной метод для обработки подключений клиента.
     * Выполняет установку потоков, регистрацию пользователя,
     * и обработку сообщений от клиента.
     */
    @Override
    public void run() {
        try {
            setupClientStreams();
            verifyAndRegisterUsername();
            processClientMessages();
//        } catch (Exception e) {
//            System.err.println("Ошибка при обработке клиента: " + e.getMessage());
        } catch (IOException e) {
            if (!isClosed) {
                System.err.println("Ошибка при обработке клиента: " + e.getMessage());
            }
        } finally {
            cleanupClientResources();
        }

    }

    /**
     * Устанавливает потоки для обмена данными с клиентом.
     *
     * @throws IOException если возникла ошибка при установке потоков.
     */
    private void setupClientStreams() throws IOException {
        inputReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        outputWriter = new PrintWriter(clientSocket.getOutputStream(), true);
    }

    /**
     * Проверяет имя пользователя и регистрирует его.
     *
     * @throws IOException если возникла ошибка при чтении данных.
     */
    private void verifyAndRegisterUsername() throws IOException {
        username = inputReader.readLine(); // Читаем имя пользователя

        if (username == null) {
            throw new IOException("Имя пользователя не предоставлено.");
        }

        synchronized (connectedClients) {
            // Проверяем, занято ли имя
            if (isUsernameTaken(username)) {
                outputWriter.println("/error Имя пользователя '" + username + "' уже занято!");
                return; // Завершаем метод, но не закрываем соединение
            }

            if (SUPERADMIN_NAME.equalsIgnoreCase(username)) {
                handleSuperAdminConnection();
            } else {
                outputWriter.println("/role пользователь");
            }

            // Добавляем клиента в список подключенных
            connectedClients.add(this);
        }

        // Уведомляем других о подключении
        broadcastMessage(username + " подключился!");
        updateClientCount();
        printConnectedClients();
    }

    /**
     * Обрабатывает подключение суперадмина.
     */
    private void handleSuperAdminConnection() {
        if (superAdminConnected) {
            outputWriter.println("/error Суперадмин уже подключен.");
            return;
        }
        superAdminConnected = true;
        outputWriter.println("/role суперадмин");
    }

    /**
     * Проверяет, занято ли имя пользователя.
     * Использование функционала StreamAPI.
     *
     * @param username Имя пользователя.
     * @return true, если имя занято; иначе false.
     */
    private boolean isUsernameTaken(String username) {
        // Проверяем, есть ли клиент с таким именем
        synchronized (connectedClients) {
            return connectedClients.stream().anyMatch(client -> client.username.equalsIgnoreCase(username));
        }
    }

    /**
     * Обрабатывает сообщения от клиента.
     *
     * @throws IOException если возникла ошибка при чтении данных.
     */
    private void processClientMessages() throws IOException {
        String message;
        while ((message = inputReader.readLine()) != null) {
            if (isClosed) break;
            if ("exit".equalsIgnoreCase(message)) {
                cleanupClientResources();
                break;
            } else if (message.startsWith("/kick ")) {
                if (SUPERADMIN_NAME.equalsIgnoreCase(username)) {
                    handleKickCommand(message.substring(6).trim());
                } else {
                    outputWriter.println("/error Команда доступна только суперадмину.");
                }
            } else if ("/list".equalsIgnoreCase(message)) {
                if (!Server.isServerRunning()) {
                    outputWriter.println("/error Сервер завершает работу, список пользователей недоступен.");
                } else {
                    synchronized (connectedClients) {
                        outputWriter.println("/users " + String.join(",", getConnectedUsernames()));
                    }
                }
            } else {
//                broadcastMessage(username + ": " + message, this);
                if (!isClosed) {
                    broadcastMessage(username + ": " + message, this);
                }
            }
        }
    }

    /**
     * Обрабатывает команду /kick для отключения пользователя.
     * Использование функционала StreamAPI.
     *
     * @param targetUsername имя пользователя, которого нужно отключить
     */
    private void handleKickCommand(String targetUsername) {
        if (username.equalsIgnoreCase(targetUsername)) {
            outputWriter.println("Нельзя забанить самого себя"); // Отправляем админу в чат
            return;
        }

        synchronized (connectedClients) {
            ClientHandler targetClient = connectedClients.stream()
                    .filter(client -> client.username.equalsIgnoreCase(targetUsername))
                    .findFirst()
                    .orElse(null);

            if (targetClient != null) {
                targetClient.sendBanNotification("Вы были отключены суперадмином.");
                targetClient.cleanupClientResources(false);
                broadcastMessage("Пользователь " + targetUsername + " был отключён суперадмином.");
                updateClientCount();
                printConnectedClients();
            } else {
                outputWriter.println("/error Пользователь " + targetUsername + " не найден.");
            }
        }
    }

    /**
     * Отправляет уведомления о бане.
     *
     * @param reason Причина бана.
     */
    private void sendBanNotification(String reason) {
        String message = "/banned " + reason;
        outputWriter.println(message);
    }

    /**
     * Очистка ресурсов клиента, таких как потоки и сокет.
     */
    private void cleanupClientResources() {
        cleanupClientResources(true);
    }

    /**
     * Очистка ресурсов клиента с возможностью оповещения других клиентов.
     *
     * @param notifyBroadcast Флаг, указывающий, нужно ли оповещать остальных.
     */
    public void cleanupClientResources(boolean notifyBroadcast) {
        if (isClosed) return;


        if (username == null) return;

        try {
            synchronized (connectedClients) {
                connectedClients.remove(this);

                if (SUPERADMIN_NAME.equalsIgnoreCase(username)) {
                    superAdminConnected = false;
                }
            }

            if (notifyBroadcast) {
                updateClientCount();
                broadcastMessage(username + " отключился.");
                printConnectedClients();
            }
            isClosed = true;
        } catch (Exception e) {
            if (!(e instanceof javax.net.ssl.SSLException) || !"Socket closed".equals(e.getMessage())) {
                System.err.println("Ошибка при очистке клиента: " + e.getMessage());
            }
        } finally {
            try {
                // Закрываем потоки в правильном порядке
                if (inputReader != null) {
                    inputReader.close();
                }
                if (outputWriter != null) {
                    outputWriter.close();
                }

                // Закрываем сокет
                if (clientSocket != null && !clientSocket.isClosed()) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                if (!"Socket closed".equals(e.getMessage())) {
                    System.err.println("Ошибка при закрытии соединения: " + e.getMessage());
                }
            }
        }
    }

    /**
     * Получение списка всех подключенных клиентов.
     *
     * @return Список всех подключенных клиентов.
     */
    public static List<ClientHandler> getConnectedClients() {
        return connectedClients;
    }

    /**
     * Отправка сообщения всем клиентам.
     *
     * @param message Сообщение для отправки.
     */
    private void broadcastMessage(String message) {
        if (!isClosed) {
            broadcastMessage(message, null);
        }
    }

    /**
     * Отправка сообщения всем клиентам, кроме указанного.
     * Использование функционала StreamAPI.
     *
     * @param message Сообщение для отправки.
     * @param excludedClient Клиент, которому не нужно отправлять сообщение.
     */
    private void broadcastMessage(String message, ClientHandler excludedClient) {
        synchronized (connectedClients) {
            connectedClients.stream()
                    .filter(client -> client != excludedClient && !client.isClosed )
                    .forEach(client -> client.outputWriter.println(message));
        }
    }

    /**
     * Отправка сообщения текущему клиенту.
     *
     * @param message Сообщение для отправки.
     */
    public void sendMessage(String message) {
//        if (!clientSocket.isClosed() && outputWriter != null) {
//            outputWriter.println(message);
//        }
        if (clientSocket.isClosed() || outputWriter == null) {
            return; // Поток закрыт, ничего не отправляем
        }
        outputWriter.println(message);
    }

    /**
     * Обновление информации о количестве пользователей на сервере.
     */
    private void updateClientCount() {
        String userCountMessage = "Количество пользователей на сервере: " + connectedClients.size();
        broadcastMessage(userCountMessage);
        System.out.println(userCountMessage);
    }

    /**
     * Печать списка подключенных пользователей в консоль.
     */
    private void printConnectedClients() {
        synchronized (connectedClients) {
            System.out.println("Список подключенных пользователей: " + String.join(", ", getConnectedUsernames()));
        }
    }

    /**
     * Получение списка имен всех подключенных пользователей.
     * Использование функционала StreamAPI.
     *
     * @return Список имен пользователей.
     */
    private List<String> getConnectedUsernames() {
        synchronized (connectedClients) {
            return connectedClients.stream()
                    .map(client -> client.username)
                    .toList();
        }
    }
}