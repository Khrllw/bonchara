import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server implements Runnable {
    private final int port;
    private final Context context;

    public Server() {
        this.port = 3345;
        this.context = new Context();
    }

    @Override
    public void run() {
        ExecutorService executor = Executors.newCachedThreadPool();

        try {
            ServerSocket serverSocket = new ServerSocket(this.port);
            int i = 0;
            // цикл ожидания подключений
            while (!this.context.stopFlag) {
                System.out.println("Waiting connection on port:" + this.port);
                // момент ухода в ожидание подключения
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected to server");

                // создается клиентская сессия
                ClientSession clientSession = new ClientSession(clientSocket, this.context);
                i++;

                // запуск логики работы с клиентом
                executor.execute(clientSession);
                //clientSession.start();
                //if (i == 3) {
                  //  executor.shutdown();
                 //   context.stopFlag = true;
                //}
            }
            // дожидаемся завершения всех активных сессий пользователей

            while (!context.getSessionsManger().getSessions().isEmpty()) {
                TimeUnit.SECONDS.sleep(2);
                // Ожидаем выполнение всех задач.
            }
            System.out.print("\033[1;32mGood BYE!\033[0m\n");
            //executor.awaitTermination();

            serverSocket.close();


        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}