import java.io.*;
import java.net.Socket;

// основная логика клиента
public class ClientSession extends Thread {
    private final Socket socket;

    private final DataInputStream inputStream;
    private final DataOutputStream outputStream;
    private final Context context;

    public ClientSession(final Socket socket, final Context context) throws IOException, IOException {
        // задаем клиентский сокет
        this.socket = socket;
        System.out.print("Connection accepted.");

        // задаем ридер и райтер для обмена сообщениями
        this.inputStream = new DataInputStream(socket.getInputStream());
        System.out.println("DataInputStream created");

        this.outputStream = new DataOutputStream(socket.getOutputStream());
        System.out.println("DataOutputStream  created");

        this.context = context;
    }

    public void run() {
        try {

            //Рукопожатие
            //Обменялись рукопожатиями, начинаем работу
            this.work();

            //выход
            this.socket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void work() throws IOException{
        while (!socket.isClosed()) {
            this.context.getSessionsManger().addSession(this);
            System.out.println("Server reading from channel");

            // сервер ждёт в канале чтения (inputstream) получения данных клиента
            String entry = inputStream.readUTF();

            // после получения данных считывает их
            System.out.println("READ from client message - " + entry);

            // и выводит в консоль
            System.out.println("Server try writing to channel");

            // инициализация проверки условия продолжения работы с клиентом по этому сокету по кодовому слову       - quit
            if (entry.equalsIgnoreCase("quit")) {
                System.out.println("Client initialize connections suicide ...");
                outputStream.writeUTF("Server reply - " + entry + " - OK");
                outputStream.flush();
                break;
            }

            // если условие окончания работы не верно - продолжаем работу - отправляем эхо-ответ  обратно клиенту
            outputStream.writeUTF("Server reply - " + entry + " - OK");
            System.out.println("Server Wrote message to client.");

            // освобождаем буфер сетевых сообщений (по умолчанию сообщение не сразу отправляется в сеть, а сначала накапливается в специальном буфере сообщений, размер которого определяется конкретными настройками в системе, а метод  - flush() отправляет сообщение не дожидаясь наполнения буфера согласно настройкам системы
            outputStream.flush();

        }

        // если условие выхода - верно выключаем соединения
        System.out.println("Client disconnected");
        System.out.println("Closing connections & channels.");
        this.context.getSessionsManger().removeSession(this);

        // закрываем сначала каналы сокета !
        inputStream.close();
        outputStream.close();

        // пото закрываем сам сокет общения на стороне сервера!
        socket.close();
        System.out.println("Closing connections & channels - DONE.");

    }
}