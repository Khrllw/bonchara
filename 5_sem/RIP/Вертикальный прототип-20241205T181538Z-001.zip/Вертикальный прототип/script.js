// Инициализация карты
const map = L.map('map').setView([51.505, -0.09], 13);

// Добавление слоя OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Маркеры для точек A и B
let pointA = null;
let pointB = null;

// Добавление маршрута
let routeControl = null;

// Обработчик клика на карте
map.on('click', function (e) {
    const { lat, lng } = e.latlng;

    if (!pointA) {
        // Установка точки A
        pointA = L.marker([lat, lng], { draggable: true }).addTo(map).bindPopup('Точка A').openPopup();
    } else if (!pointB) {
        // Установка точки B
        pointB = L.marker([lat, lng], { draggable: true }).addTo(map).bindPopup('Точка B').openPopup();

        // Построение маршрута
        if (routeControl) {
            map.removeControl(routeControl); // Удаление предыдущего маршрута, если есть
        }

        routeControl = L.Routing.control({
            waypoints: [
                pointA.getLatLng(),
                pointB.getLatLng()
            ],
            routeWhileDragging: true, // Позволяет редактировать маршрут перетаскиванием
            show: true,
            createMarker: () => null // Отключение дополнительных маркеров от маршрута
        }).addTo(map);
    } else {
        alert('Маршрут уже построен. Перетащите точки A или B для изменения маршрута.');
    }
});

// Сброс точек A и B
function resetPoints() {
    if (pointA) map.removeLayer(pointA);
    if (pointB) map.removeLayer(pointB);
    if (routeControl) map.removeControl(routeControl);
    pointA = null;
    pointB = null;
}

// Добавление кнопки для сброса маршрута
const resetButton = L.control({ position: 'topright' });
resetButton.onAdd = function () {
    const div = L.DomUtil.create('div', 'leaflet-bar leaflet-control leaflet-control-custom');
    div.style.backgroundColor = 'white';
    div.style.width = '30px';
    div.style.height = '30px';
    div.style.cursor = 'pointer';
    div.innerHTML = '⟲';
    div.title = 'Сбросить маршрут';
    div.onclick = resetPoints;
    return div;
};
resetButton.addTo(map);
