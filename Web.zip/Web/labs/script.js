function change_fone(){
    html.form.style.backgroundColor = "pink";
}