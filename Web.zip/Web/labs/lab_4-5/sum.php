<?php
$var1 = $_GET['var1'];
$var2 = $_GET['var2'];
echo $var1, ' + ', $var2, ' = ', $var1 + $var2;
?>