<?php
$today = getdate();
echo 'I say hello at ', $today['month'], ' ', $today['mday'], ', ', $today['year'];
?>