<?php
echo "Каталог для хранения документов на сервере: ".$_SERVER['DOCUMENT_ROOT'];
echo "<br>IP-адрес сервера: ".$_SERVER['SERVER_ADDR'];
?>	